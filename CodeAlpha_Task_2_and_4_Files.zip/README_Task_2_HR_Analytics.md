# CodeAlpha Task 2: Human Resources Analytics

## Objective
Create an interactive Power BI dashboard to analyze recruitment/employee joining trends, employee turnover, satisfaction, and performance.

## Dataset
`HR_Data.xlsx`

## Required Dashboard Visuals
- Total Employees
- Average Salary
- Average Performance
- Employee Turnover Rate
- Employees by Department
- Gender Distribution
- Average Performance by Department
- Employee Joining Trend
- Employee Satisfaction by Department
- Employee details table
- Department, Gender, and Joining Year filters

## DAX Measures
Use your actual imported table name in place of `HR_Data` if Power BI assigns a different name.

```DAX
Total Employees = COUNTROWS(HR_Data)

Average Salary = AVERAGE(HR_Data[Salary])

Average Performance = AVERAGE(HR_Data[Performance_Score])

Average Satisfaction = AVERAGE(HR_Data[Satisfaction])

Employees Left =
CALCULATE(
    COUNTROWS(HR_Data),
    HR_Data[Exit_Status] = "Yes"
)

Current Employees =
CALCULATE(
    COUNTROWS(HR_Data),
    HR_Data[Exit_Status] = "No"
)

Turnover Rate =
DIVIDE(
    [Employees Left],
    [Total Employees],
    0
) * 100
```

## Tools
- Power BI Desktop
- Microsoft Excel
- Power Query
- DAX

## Output
Save the completed Power BI report as:

`CodeAlpha_HR_Analytics.pbix`
