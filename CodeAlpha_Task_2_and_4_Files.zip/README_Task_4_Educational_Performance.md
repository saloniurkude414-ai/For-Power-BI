# CodeAlpha Task 4: Educational Performance and Resource Allocation

## Objective
Develop a Power BI dashboard to evaluate student performance and analyze educational resource usage.

## Dataset
`Education_Data.xlsx`

## Required Dashboard Areas
- Academic performance metrics
- Resource usage analysis
- Identification of performance gaps
- Data-driven education management insights

## Suggested Dashboard Visuals
- Total Students
- Average Marks
- Average Attendance
- Average Marks by Department
- Resource Usage Distribution
- Pass/Fail Analysis
- Students Requiring Improvement
- Department, Gender, and Result filters

## DAX Measures
Use your actual imported table name in place of `Education_Data` if Power BI assigns a different name.

```DAX
Total Students = COUNTROWS(Education_Data)

Average Marks = AVERAGE(Education_Data[Marks])

Average Attendance = AVERAGE(Education_Data[Attendance])

Passed Students =
CALCULATE(
    COUNTROWS(Education_Data),
    Education_Data[Result] = "Pass"
)

Failed Students =
CALCULATE(
    COUNTROWS(Education_Data),
    Education_Data[Result] = "Fail"
)

Pass Percentage =
DIVIDE(
    [Passed Students],
    [Total Students],
    0
) * 100
```

## Tools
- Power BI Desktop
- Microsoft Excel
- Power Query
- DAX

## Output
Save the completed Power BI report as:

`CodeAlpha_Educational_Performance.pbix`
